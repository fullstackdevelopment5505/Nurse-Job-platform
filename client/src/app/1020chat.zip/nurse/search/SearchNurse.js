import React , { useEffect, useState }from "react";
import { useSelector } from "react-redux";
import Header from "../../nurse/layout/Header";
import Footer from "../../nurse/layout/Footer";
import { connect} from "react-redux";
import './SearchNurse.scss'
import BreadCrumb from "../layout/BreadCrumb";
import MenuItem from '@material-ui/core/MenuItem';
import { Link } from 'react-router-dom';
import {
    TextField,
  } from "@material-ui/core";
import {
    makeStyles,
} from "@material-ui/core/styles";
  import FormGroup from '@material-ui/core/FormGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import * as actions from '../../../app/actions';
import * as authDuck from '../../../app/store/ducks/auth.duck';
import * as activityDuck from '../../../app/store/ducks/activity.duck';
import * as categoryDuck from '../../../app/store/ducks/category.duck';
import * as userDuck from '../../../app/store/ducks/user.duck';
import default_img from './../../assets/default_profile.png';

// const categories = [
//     {
//       value: 'USD',
//       label: 'Filter by Category',
//     },
//     {
//       value: 'EUR',
//       label: 'Nurse2',
//     },
//     {
//       value: 'BTC',
//       label: 'Nurse3',
//     },
//     {
//       value: 'JPY',
//       label: 'Nurse4',
//     },
//   ];
const locations = [
    {
      value: 'USD',
      label: 'Filter by Location List',
    },
    {
      value: 'EUR',
      label: 'London(2)',
    },
    {
      value: 'BTC',
      label: 'New York(1)',
    }
  ];
function SearchNurse(props) {
  const [advanceflag,setAdvanceflag] = React.useState(false);
  const [allcategory, setAllcategory]= React.useState([]);
  const [filterCategory, setFilterCategory] = React.useState('filter');
  const [allnurses, setAllnurses]= React.useState([]);
  const [selected, setSelected] = React.useState([]);
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(5);
  const [values, setValues] = React.useState({
        name: 'Cat in the Hat',
        age: '',
        multiline: 'Controlled',
        currency: 'EUR',
      });
    
    const useStyles = makeStyles(theme => ({
        container: {
          display: "flex",
          flexWrap: "wrap"
        },
        textField1:{
            marginLeft:'5px',
            marginRight:'5px'
        },
        textField: {
          marginLeft: theme.spacing(0),
          marginRight: theme.spacing(0),
          marginTop: '8px',
          marginBottom: '8px',
        },
        dense: {
          marginTop: theme.spacing(2)
        },
        menu: {
          width: 200
        },
        termps_check:{
          marginRight:'3px'
        }
      }));
      const handleChange = name => event => {
        setValues({ ...values, [name]: event.target.value });
      };
      function handleChangePage(event, newPage) {
        setPage(newPage);
      }
    
      function handleChangeRowsPerPage(event) {
        setRowsPerPage(+event.target.value);
      }
    
      const isSelected = name => selected.indexOf(name) !== -1;
    
      const emptyRows = rowsPerPage - Math.min(rowsPerPage, allnurses.length - page * rowsPerPage);
    
    const classes = useStyles();
    useEffect(() => {
        setAllcategory(props.allcategories || []);
        setAllnurses(props.nurses || []);
      }, [props])
    return (
    <>
     <Header/>
     <BreadCrumb title="Jobs" base="Home"/>
     <section className="jobs widget-filter-top" style={{backgroundColor:'white'}}>
         <div className="container">
            <FormGroup row>
                <div className="col-lg-9 col-xs-12">
                    <div className="row">
                        <div className="col-md-4">
                            <TextField
                                id="standard-bare"
                                className={classes.textField}
                                margin="normal"
                                variant="outlined"
                                placeholder="e.g. talented nurse"
                                inputProps={{ "aria-label": "bare" }}
                            />
                        </div>
                        <div className="col-md-4">
                                <TextField
                                id="outlined-select-currency"
                                select
                                placeholder="Category"
                                className={classes.textField}
                                value={filterCategory}
                                onChange={(e)=>{setFilterCategory(e.target.value);}}
                                SelectProps={{
                                MenuProps: {
                                    className: classes.menu,
                                },
                                }}
                                margin="normal"
                                variant="outlined"
                            >
                                <MenuItem key='filter' value='filter'>
                                    Filter by Category
                                </MenuItem>
                                {allcategory.map(option => (
                                <MenuItem key={option._id} value={option._id}>
                                    {option.name}
                                </MenuItem>
                                ))}
                            </TextField>
                        </div>
                        <div className="col-md-4">
                            <TextField
                                id="outlined-select-currency"
                                select
                                placeholder="Filter by Location List"
                                className={classes.textField}
                                value={values.currency || undefined}
                                onChange={handleChange('currency')}
                                SelectProps={{
                                MenuProps: {
                                    className: classes.menu,
                                },
                                }}
                                margin="normal"
                                variant="outlined"
                            >
                                {locations.map(option => (
                                <MenuItem key={option.value} value={option.value}>
                                    {option.label}
                                </MenuItem>
                                ))}
                            </TextField>
                        </div>
                    </div>
                </div>
                <div className="col-lg-3 col-xs-12 margin-auto" >
                    <div className="flex-middle space-bottom-15">
                        <div className="visiable-line">
                            <button className="button btn btn-theme-second">Filter</button>
                        </div>
                        <a href="#" className="toggle-adv visiable-line btn button"onClick={() => {
                                    advanceflag? setAdvanceflag(false):setAdvanceflag(true);
                                  }}>
                          <i className="fas fa-cog"></i> 
                          Advance	
                        </a>
                    </div>
                </div>
                {advanceflag?<div className="row" style={{width:'100%'}}>
                        <div className="col-lg-9 col-xs-12">
                        <div className="row">
                            <div className="col-md-4">
                                <TextField
                                    id="outlined-select-currency"
                                    placeholder="All Location"
                                    className={classes.textField}
                                    value='All Location'
                                    onChange={handleChange('currency')}
                                    SelectProps={{
                                    MenuProps: {
                                        className: classes.menu,
                                    },
                                    }}
                                    margin="normal"
                                    variant="outlined"
                                >
                                </TextField>
                            </div>
                            <div className="col-md-4">
                                <TextField
                                    id="outlined-select-currency"
                                    select
                                    placeholder="Category"
                                    className={classes.textField}
                                    value='Filter By Job Type'
                                    onChange={handleChange('currency')}
                                    SelectProps={{
                                    MenuProps: {
                                        className: classes.menu,
                                    },
                                    }}
                                    margin="normal"
                                    variant="outlined"
                                >
                                    <MenuItem key='Filter By Job Type' value='Filter By Job Type'>
                                        Filter By Job Type
                                    </MenuItem>
                                </TextField>
                            </div>
                            <div className="col-md-4">
                                <TextField
                                    id="outlined-select-currency"
                                    select
                                    placeholder="Filter by Level"
                                    className={classes.textField}
                                    value='Filter by Level'
                                    onChange={handleChange('currency')}
                                    SelectProps={{
                                    MenuProps: {
                                        className: classes.menu,
                                    },
                                    }}
                                    margin="normal"
                                    variant="outlined"
                                >
                                    <MenuItem key='Filter by Level' value='Filter by Level'>
                                        Filter by Level
                                    </MenuItem>
                                </TextField>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-3 col-xs-12 margin-auto" >
                        <TextField
                            id="outlined-select-currency"
                            select
                            placeholder="Category"
                            className={classes.textField}
                            value='All'
                            onChange={handleChange('currency')}
                            SelectProps={{
                            MenuProps: {
                                className: classes.menu,
                            },
                            }}
                            margin="normal"
                            variant="outlined"
                        >
                                    <MenuItem key='All' value='All'>
                                        All
                                    </MenuItem>
                                </TextField>
                    </div></div>:<div/>
                }
                {advanceflag?<div className="row" style={{width:'100%'}}>
                        <div className="col-lg-9 col-xs-12">
                        <div className="row">
                            <div className="col-md-4">
                            <TextField
                                    id="outlined-select-currency"
                                    select
                                    placeholder="Category"
                                    className={classes.textField}
                                    value='Filter By Industry'
                                    onChange={handleChange('currency')}
                                    SelectProps={{
                                    MenuProps: {
                                        className: classes.menu,
                                    },
                                    }}
                                    margin="normal"
                                    variant="outlined"
                                >
                                    <MenuItem key='Filter By Industry' value='Filter By Industry'>
                                        Filter By Industry
                                    </MenuItem>
                                </TextField>
                            </div>
                            <div className="col-md-4">
                                <TextField
                                    id="outlined-select-currency"
                                    select
                                    placeholder="Category"
                                    className={classes.textField}
                                    value='Filter By Qualification'
                                    onChange={handleChange('currency')}
                                    SelectProps={{
                                    MenuProps: {
                                        className: classes.menu,
                                    },
                                    }}
                                    margin="normal"
                                    variant="outlined"
                                >
                                    <MenuItem key='Filter By Qualification' value='Filter By Qualification'>
                                        Filter By Qualification
                                    </MenuItem>
                                </TextField>
                            </div>
                            <div className="col-md-4">
                                <TextField
                                    id="outlined-select-currency"
                                    select
                                    placeholder="Filter by Level"
                                    className={classes.textField}
                                    value='Filter by Level'
                                    onChange={handleChange('currency')}
                                    SelectProps={{
                                    MenuProps: {
                                        className: classes.menu,
                                    },
                                    }}
                                    margin="normal"
                                    variant="outlined"
                                >
                                    <MenuItem key='Filter by Level' value='Filter by Level'>
                                        Filter by Level
                                    </MenuItem>
                                </TextField>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-3 col-xs-12 margin-auto" >
                        <TextField
                            id="outlined-select-currency"
                            select
                            placeholder="Category"
                            className={classes.textField}
                            value='Filter by Experience'
                            onChange={handleChange('currency')}
                            SelectProps={{
                            MenuProps: {
                                className: classes.menu,
                            },
                            }}
                            margin="normal"
                            variant="outlined"
                        >
                                    <MenuItem key='Filter by Experience' value='Filter by Experience'>
                                        Filter by Experience
                                    </MenuItem>
                                </TextField>
                    </div></div>:<div/>
                }
            </FormGroup>
         </div>
     </section>
     <section style={{backgroundColor:'white'}}>
            <div className="container jobSecond">
                <div className="row">
                    <div className="results-filter-wrapper" style={{width:'100%'}}>
                    <h3 className="title">Your Selected</h3>
                    <div className="inner">
                        <ul className="results-filter">
                            <li><a href="https://www.demoapus-wp1.com/workio/jobs-list/?filter-title=&amp;filter-category=&amp;filter-center-location=&amp;filter-center-latitude=&amp;filter-center-longitude=&amp;filter-type=&amp;filter-salary-from=1200&amp;filter-salary-to=8000&amp;filter-date-posted=all&amp;filter-custom-industry=&amp;filter-custom-qualification=&amp;filter-custom-level=&amp;filter-custom-experience="><span className="close-value">x</span>London</a></li>
                            <li><a href="https://www.demoapus-wp1.com/workio/jobs-list/?filter-title=&amp;filter-category=&amp;filter-location=52&amp;filter-center-location=&amp;filter-center-latitude=&amp;filter-center-longitude=&amp;filter-type=&amp;filter-salary-from=1200&amp;filter-salary-to=8000&amp;filter-custom-industry=&amp;filter-custom-qualification=&amp;filter-custom-level=&amp;filter-custom-experience="><span className="close-value">x</span>All</a></li>
                        </ul>
                        <a href="https://www.demoapus-wp1.com/workio/jobs-list/">
                        <i className="fas fa-trash-alt"></i>
                        Clear all</a>
                        </div>
                    </div>
                </div>
                <div className="row">
                    <div className="jobs-alert-ordering-wrapper" style={{width:'100%'}}>
                        <div className="results-count">
                            Showing {page*rowsPerPage + 1} – {allnurses.length >= (page + 1)*rowsPerPage ?  (page + 1)*rowsPerPage : allnurses.length} of {allnurses.length} results
                        </div>
                    {/* <div className="job-rss-btn margin-left-15">
                            <a className="job-rss-link" href="https://www.demoapus-wp1.com/workio/?feed=job_listing_feed&amp;filter-title&amp;filter-category&amp;filter-location=52&amp;filter-center-location&amp;filter-center-latitude&amp;filter-center-longitude&amp;filter-type&amp;filter-salary-from=1200&amp;filter-salary-to=8000&amp;filter-date-posted=all&amp;filter-custom-industry&amp;filter-custom-qualification&amp;filter-custom-level&amp;filter-custom-experience" target="_blank">
                                <i className="fas fa-rss-square"></i>
                                RSS Feed
                            </a>
                    </div> */}
                    <div className="jobs-ordering-wrapper" style={{display:'flex'}}>
                            {/* <TextField
                                    id="outlined-select-currency"
                                    select
                                    placeholder="Category"
                                    className={classes.textField1}
                                    value='Default'
                                    margin="normal"
                                    variant="outlined"
                                >
                                    <MenuItem key='Default' value='Default'>
                                        Default
                                    </MenuItem>
                                    <MenuItem key='Newest' value='Newest'>
                                    Newest
                                    </MenuItem>
                                    <MenuItem key='Oldest' value='Oldest'>
                                    Oldest
                                    </MenuItem>
                                </TextField> */}
                            <TextField
                                    id="outlined-select-currency"
                                    select
                                    placeholder="Category"
                                    className={classes.textField1}
                                    value={rowsPerPage}
                                    onChange={(e)=>{setRowsPerPage(e.target.value); setPage(0)}}
                                    margin="normal"
                                    variant="outlined"
                                >
                                    <MenuItem key='5 Per Pages' value={5}>
                                    5 Per Pages
                                    </MenuItem>
                                    <MenuItem key='10 Per Pages' value={10}>
                                    10 Per Pages
                                    </MenuItem>
                                </TextField>
                    </div>
                    </div>
                </div>
                <div className="row">
                    <div className="jobs-wrapper items-wrapper">
                    {allnurses.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                            .map((row, index) => {
                                console.log('--------------')
                                console.log(row)
                                return (
                                <div key={index}className="style-list-jobs">
						            <article id="post-549" className="job-list map-item job-style-inner post-549 job_listing type-job_listing status-publish has-post-thumbnail hentry job_listing_type-internship job_listing_category-retail job_listing_location-new-york job_listing_tag-digital job_listing_tag-interviews job_listing_tag-jobs job_listing_tag-media" data-latitude="40.776629" data-longitude="-73.952531">
                                {/* <div className="featured-urgent-label">
                                <span className="featured label-no-icon">Featured</span>
                                    <span className="urgent">Urgent</span>
                                </div> */}
                                <div className="flex-middle-sm job-list-container">
                                    <div className="candidate-logo candidate-thumbnail">
                                        <a href="https://www.demoapus-wp1.com/workio/candidate/meg-cabot/">
                                            <div className="image-wrapper image-loaded">
                                                <img width="180" height="180" src={row.profilePhoto ===''?default_img:row.profilePhoto} className="attachment-workio-logo-size size-workio-logo-size unveil-image" alt=""  sizes="(max-width: 180px) 100vw, 180px"/>
                                            </div>
                                        </a>
                                    </div>
                                    <div className="job-information">
                                        <div className="title-wrapper">
                                            <h2 className="job-title">
                                                <a href="https://www.demoapus-wp1.com/workio/job/python-3-bootcamp/" rel="bookmark">{row.firstName + ' '+ row.lastName}</a>
                                            </h2>                
                                        </div>
                                        <div className="job-employer-info-wrapper">
                                            <h3 className="employer-title">
                                                <a href="#">
                                                   {row.title}
                                                </a>
                                            </h3>
                                            <div className="job-salary">
                                                $<span className="price-text">{row.salary}</span> / month
                                            </div>    
                                            <div className="job-types">
                    							<div className="job-type with-title">
						            	            <a className="type-job" href="https://www.demoapus-wp1.com/workio/job-type/internship/" style={{color: '#63ace5'}}>
                                                        123213
                                                    </a>
                		        		    	</div>
	                                        </div>
                                      </div>            
                                    </div>
                                    {/* <div className="job-location with-icon">
                                        <i className="ti-location-pin"></i>
                                        <a href="#">
                                            {row.address}
                                        </a>
                                    </div>             */}
                                    <div className="deadline-time">Application ends: <strong>October 1, 2025</strong></div>
									<Link to="/messages" className="btn btn-apply btn-apply-job-internal-required">Chat Now<i className="next flaticon-right-arrow"></i></Link>
									{/* <a href="#" className="btn btn-apply btn-apply-job-internal-required">Apply Now<i className="next flaticon-right-arrow"></i></a> */}
                                    <div className="job-apply-internal-required-wrapper" style={{display:'none'}}>
		                                <div className="msg-inner">Please login with "Candidate" to apply</div>
                                    </div>
                                </div>
                            </article>  
					    </div>
                            )})
                }
                    </div>
                    {allnurses.length > rowsPerPage?
                   <div className="jobs-pagination-wrapper main-pagination-wrapper" style={{margin:'auto'}}>
	                    <ul className="pagination">
                            {page >= 1 ?<li><a className="prev page-numbers"onClick={() => {setPage(page - 1);}}><i className="fas fa-chevron-left"></i></a></li>:<></>}
                            {page >= 1 ?<li><a className="page-numbers"onClick={() => {setPage(page - 1);}}>{page}</a></li>:<></>}
                            <li><span className="page-numbers current">{page + 1}</span></li>
                            {(page + 1)* rowsPerPage <= allnurses.length ?<li><a className="page-numbers"onClick={() => {setPage(page + 1);}}>{page + 2}</a></li>:<></>}
                            {(page + 1)* rowsPerPage <= allnurses.length ?<li><a className="next page-numbers"onClick={() => {setPage(page + 1);}}><i className="fas fa-chevron-right"></i></a></li>:<></>}
                        </ul>
                    </div>:<></>}
                </div>
            </div>
     </section>
     <Footer/>
    </>
  );
}
const mapStateToProps = (state) => ({
    nurses: state.user.nurses,
    allcategories:state.category.allcategories
  })
  
  export default connect(
      mapStateToProps,
      {...authDuck.actions, ...activityDuck.actions, ...userDuck.actions, ...categoryDuck.actions}
  )(SearchNurse);
  