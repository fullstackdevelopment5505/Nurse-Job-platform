import React from 'react';
import './Main.sass';
import {
    FiInfo,
    FiPhone,
    FiVideo,
    FiStar,
} from "react-icons/fi";
import {useDispatch, useSelector} from "react-redux";
import Actions from "../../store/variables/actions/Actions";
// import Config from '../../config';
import * as UIkit from "uikit";
import View from "../../store/variables/actions/View";
import Views from "../../store/variables/Views";

const ChatHeader = ({mobile}) => {
    const dispatch = useDispatch();

    const room = useSelector(state => state.room);
    const user = useSelector(state => state.user);
    // const status = useSelector(state => state.status);

    let other = {};

    if (!room.isGroup && room.people) {
        room.people.forEach(person => {
            if (person._id !== user.id) other = person;
        });
    }

    let isFavorite = false;

    user.favorites && user.favorites.forEach(favorite => {
        if (favorite._id === room._id) isFavorite = true;
    });

    const getStatus = () => {
        // if (status.online.includes(other._id)) return 'online';
        // if (status.away.includes(other._id)) return 'away';
        // if (status.busy.includes(other._id)) return 'busy';
        return 'offline';
    };

    const getClass = () => {
        return'green'
        // if (status.online.includes(other._id)) return 'green';
        // if (status.away.includes(other._id)) return 'orange';
        // if (status.busy.includes(other._id)) return 'red';
        // return 'gray';
    };
   
    let online = 0;
    let away = 0;
    let busy = 0;

    // if (room.isGroup) room.people.forEach(person => {
    //     if (status.online.includes(person._id)) online++;
    //     if (status.away.includes(person._id)) away++;
    //     if (status.busy.includes(person._id)) busy++;
    // });

    return (
        <div className="header header-main">
            <div className="left">
                <div className="name">
                    {/* {room.isGroup ? room.title : `${other.firstName} ${other.lastName}`} */}
                </div>
                <div className="status-dot">
                    {/* <div className={`dot ${getClass()}`} hidden={room.isGroup} />
                    <div className="status" hidden={room.isGroup}>{getStatus()}</div>
                    <div className="status" hidden={!room.isGroup}>{room.people.length} members</div>
                    <div className="status group" hidden={!room.isGroup}>{online} online</div>
                    <div className="status group" hidden={!room.isGroup}>{away} away</div>
                    <div className="status group" hidden={!room.isGroup}>{busy} busy</div> */}
                </div>
            </div>
            <div className="right">
                <div
                    className="button"
                    onClick={() => dispatch({type: Actions.TOGGLE_FAVORITE, roomID: room._id})}
                    style={isFavorite ? {color: '#DA7D02'} : {}}
                >
                    <FiStar/>
                </div>
                {/* <div className="button" onClick={call}>
                    <FiPhone/>
                </div>
                <div className="button" onClick={videoCall}>
                    <FiVideo/>
                </div> */}
                <div className="button" onClick={() => dispatch({ type: View.NAVIGATE, nav: Views.DETAILS })} hidden={!mobile}>
                    <FiInfo/>
                </div>
            </div>
        </div>
    );
};

export default ChatHeader;
