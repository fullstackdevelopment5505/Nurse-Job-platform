export default {
    NAVIGATE: 'NAVIGATE',
};
