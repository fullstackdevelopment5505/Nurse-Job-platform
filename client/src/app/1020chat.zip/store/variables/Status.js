export default {
    SUCCESS: 'SUCCESS',
    ERROR: 'ERROR',
    PROGRESS: 'PROGRESS',
};
