import Actions from "../variables/actions/Actions";
import Status from "../variables/Status";
import axios from "axios";
import User from "../variables/actions/User";
import { call, fork, put, select, take } from "redux-saga/effects";
import { eventChannel } from 'redux-saga';
export const actionTypes = {
    UPLOAD_SUCCESS: "UPLOAD_SUCCESS",
    UPLOAD_PROGRESS: "UPLOAD_PROGRESS",
    UPLOAD_ERROR:'UPLOAD_ERROR',
    UPLOAD_IMAGE:'UPLOAD_IMAGE',
    USER_LOGOUT:'USER_LOGOUT',
};
const initialState = {
    ref: 0,
    progress: -1,
};

export const apiImagesReducer = (state = initialState, action) => {
    switch (action.type) {
        case Actions.UPLOAD_SUCCESS:
            return {
                ...state, [action.ref]: {...state[action.ref], status: Status.SUCCESS, image: action.result.data.image, progress: 100}
            };
        case Actions.UPLOAD_PROGRESS:
            return {
                ...state, [action.ref]: {...state[action.ref], status: Status.PROGRESS, progress: action.data}
            };
        case Actions.UPLOAD_ERROR:
            return {
                ...state, [action.ref]: {...state[action.ref], status: Status.ERROR, err: action.err, progress: -1}
            };
        case Actions.UPLOAD_IMAGE:
            return {
                ...state, ref: state.ref + 1
            };
        case User.USER_LOGOUT:
            return initialState;
        default:
            return state;
    }
}
export const actions = {
    // sendMsg:    
    uploadSuccess: userData => ({ type: actionTypes.UPLOAD_SUCCESS, payload: userData }),
    uploadProgress: userData => ({ type: actionTypes.UPLOAD_PROGRESS, payload: userData }),
    uploadImage: userData => ({ type: actionTypes.UPLOAD_IMAGE, payload: userData }),
    userLogout: () => ({ type: actionTypes.USER_LOGOUT}),
};
const upload = (image, token, crop, onProgress) => {
    const url = '/api/upload';

    const data = new FormData();

    data.append('image', image, image.name);
    data.append('crop', crop);

    const config = {
        onUploadProgress: onProgress,
        withCredentials: true,
        headers: {'Authorization': "Bearer " + token},
    };

    return axios.post(url, data, config);
};
const createUploader = (image, token, crop) => {

    let emit;
    const chan = eventChannel(emitter => {

        emit = emitter;
        return () => {};
    });

    const uploadPromise = upload(image, token, crop, (event) => {
        if (event.loaded.total === 1) {
            emit(Actions.UPLOAD_END);
        }

        emit(event.loaded.total || -1);
    });

    return [ uploadPromise, chan ];
};

const getToken = state => state.user.token;
function* watchOnProgress(chan, ref) {
    while (true) {
        const data = yield take(chan);
        yield put({ type: actionTypes.UPLOAD_PROGRESS, data, ref });
    }
}
export function* saga(action) {
    const image = action.image;
    const token = yield select(getToken);
    const [ uploadPromise, chan ] = createUploader(image, token, action.crop);
    yield fork(watchOnProgress, chan, action.ref);

    try {
        const result = yield call(() => uploadPromise);
        yield put({ type: actionTypes.UPLOAD_SUCCESS, result, ref: action.ref });
        if (action.next) yield put(action.next);
    } catch (err) {
        yield put({ type: actionTypes.UPLOAD_ERROR, err: err.response, ref: action.ref });
    }
}