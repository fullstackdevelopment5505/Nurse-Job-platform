import {combineReducers} from "redux";
import admin from './admin';
import images from './images';
import panel from './panel';
import search from './search';
import room from './room';
import user from './user';
import rtc from './rtc';
import selection from './selection';
import status from './status';
import view from './view';

export default combineReducers({
    admin, images, panel, search, room, rtc, selection, status, user, view
});
