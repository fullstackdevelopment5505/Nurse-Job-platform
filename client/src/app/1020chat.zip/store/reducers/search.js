export const actionTypes = {
    SEARCH: "SEARCH",
    SEARCH_RESULT: "SEARCH_RESULT",
    USER_LOGOUT:'USER_LOGOUT'
};
const initialState = {
    text: '',
};

export const apisearchReducer = (state = initialState, action) => {
    switch (action.type) {
        case actionTypes.SEARCH:
            return {
                ...state, text: action.search
            };
        case actionTypes.SEARCH_RESULT:
            return {
                ...state, ...action.data
            };
        case actionTypes.USER_LOGOUT:
            return initialState;
        default:
            return state;
    }
};
export const actions = {
    search: userData => ({ type: actionTypes.SEARCH, payload: userData }),
    searchResult: userData => ({ type: actionTypes.SEARCH_RESULT, payload: userData }),
    userLogout: () => ({ type: actionTypes.USER_LOGOUT}),
  };
  
  export function* saga() {
  }