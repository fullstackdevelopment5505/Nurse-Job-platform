import xss from "xss";
export const actionTypes = {
    CREATE_ROOM_RESULT: "CREATE_ROOM_RESULT",
    JOIN_ROOM_RESULT: "JOIN_ROOM_RESULT",
    ADD_MESSAGE: "ADD_MESSAGE",
    MORE_MESSAGES_RESULT: "MORE_MESSAGES_RESULT",
    MORE_IMAGES_RESULT: "MORE_IMAGES_RESULT",
    USER_LOGOUT: "USER_LOGOUT",
};
const initialState = {
    images: [],
    messages: [],
    firstMessageID: null,
    lastMessageID: null,
};
const createRoom = counterpart => {
    window.socket.emit('create-room', { counterpart });
};

const joinRoom = roomID => {
    window.socket.emit('join-room', { roomID });
};

const listRooms = () => {
    window.socket.emit('list-rooms', {});
};

const moreMessages = (roomID, messageID) => {
    window.socket.emit('more-messages', { roomID, messageID });
};

const moreImages = (roomID, messageID) => {
    window.socket.emit('more-images', { roomID, messageID });
};

const createGroup = (people, title, picture) => {
    window.socket.emit('create-group', { people, title, picture });
};

const moreRooms = roomID => {
    window.socket.emit('more-rooms', { roomID });
};
export const apiroomReducer = (state = initialState, action) => {
    switch (action.type) {
        case actionTypes.CREATE_ROOM_RESULT:
            createRoom(action.payload.counterpart);
            return {
                ...state,
                ...action.payload.data.room,
                picture: action.payload.data.room.picture || null,
                firstMessageID: action.payload.data.room.messages.length > 0 ? action.payload.data.room.messages[0]._id : state.firstMessageID,
                lastMessageID: action.payload.data.room.messages.length > 0 ? action.payload.data.room.messages[action.data.room.messages.length - 1]._id : state.lastMessageID,
            };
        case actionTypes.JOIN_ROOM_RESULT:
            joinRoom(action.payload.roomID)
            return {
                ...state,
                ...action.payload.data.room,
                picture: action.payload.data.room.picture || null,
                firstMessageID: action.payload.data.room.messages.length > 0 ? action.payload.data.room.messages[0]._id : state.firstMessageID,
                lastMessageID: action.payload.data.room.messages.length > 0 ? action.payload.data.room.messages[action.data.room.messages.length - 1]._id : state.lastMessageID,
            };
        case actionTypes.ADD_MESSAGE:
            let message = action.payload.message;
            message.content = xss(message.content);
            return {
                ...state,
                messages: [...state.messages, message],
                images: action.payload.message.type === 'image' ? [action.payload.message, ...state.images] : state.images,
                lastMessageID: action.payload.message._id,
            };
        case actionTypes.MORE_MESSAGES_RESULT:
            moreMessages(action.payload.roomID, action.payload.messageID);
            return {
                ...state,
                messages: [...action.payload.data.messages, ...state.messages],
                firstMessageID: action.payload.data.messages.length > 0 ? action.payload.data.messages[0]._id : state.firstMessageID,
            };
        case actionTypes.MORE_IMAGES_RESULT:
            return {
                ...state,
                images: [...state.images, ...action.payload.data.images],
            };
        case actionTypes.USER_LOGOUT:
            return initialState;
        default:
            return state;
    }
};
export const actions = {
    createRoomResult: userData => ({ type: actionTypes.CREATE_ROOM_RESULT, payload: userData }),
    joinRoomResult: userData => ({ type: actionTypes.JOIN_ROOM_RESULT, payload: userData }),
    addMessage: userData => ({ type: actionTypes.ADD_MESSAGE, payload: userData }),
    moreMessagesResult: userData => ({ type: actionTypes.MORE_MESSAGES_RESULT, payload: userData }),
    moreImagesResult: userData => ({ type: actionTypes.MORE_IMAGES_RESULT, payload: userData }),
    userLogout: () => ({ type: actionTypes.USER_LOGOUT}),
  };
  
  export function* saga() {
  }