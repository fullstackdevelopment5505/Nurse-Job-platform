export const actionTypes = {
    ADMIN_USER_CREATE_RESULT: "ADMIN_USER_CREATE_RESULT",
    ADMIN_USER_UPDATE_RESULT: "ADMIN_USER_UPDATE_RESULT",
    ADMIN_USER_DELETE_RESULT: "ADMIN_USER_DELETE_RESULT",
};
const initialState = {
    error: null,
    status: null,
    username: null,
    view: null,
};
export const apiadminReducer= (state = initialState, action) => {
    switch (action.type) {
        case actionTypes.ADMIN_USER_CREATE_RESULT:
            window.socket.emit('search', { search: action.search })
            return {
                ...state, error: null, status: 'CREATED', username: action.username, view: null,
            };
        case actionTypes.ADMIN_USER_UPDATE_RESULT:
            window.socket.emit('search', { search: action.search })
            return {
                ...state, error: null, status: 'UPDATED', username: action.username, view: null,
            };
        case actionTypes.ADMIN_USER_DELETE_RESULT:
            window.socket.emit('search', { search: action.search })
            return {
                    ...state, error: null, status: 'DELETED', username: action.username, view: null,
            };
        default:
            return state;
    }
}
export const actions = {
    adminUserCreateResult: userData => ({ type: actionTypes.ADMIN_USER_CREATE_RESULT, payload: userData }),
    adminUserUpdateResult: userData => ({ type: actionTypes.ADMIN_USER_UPDATE_RESULT, payload: userData }),
    adminUesrDeleteResult: userData => ({ type: actionTypes.ADMIN_USER_DELETE_RESULT, payload: userData }),
  };
  
  export function* saga() {
  }
  