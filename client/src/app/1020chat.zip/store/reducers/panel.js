import User from "../variables/actions/User";
import Actions from "../variables/actions/Actions";
export const actionTypes = {
    LIST_ROOMS: "LIST_ROOMS",
    LIST_ROOMS_RESULT: "LIST_ROOMS_RESULT",
    MORE_ROOMS_RESULT: "MORE_ROOMS_RESULT",
    USER_LOGOUT: "USER_LOGOUT",
};
const initialState = {
    rooms: [],
};
const listRooms = () => {
    window.socket.emit('list-rooms', {});
};
export const apipanelReducer= (state = initialState, action) => {
    switch (action.type) {
        case actionTypes.LIST_ROOMS:
            console.log('list_rooms_action')
            listRooms();
            return state;
        case actionTypes.LIST_ROOMS_RESULT:
            console.log('LIST_ROOMS_RESULT')
            return {
                ...state, rooms: action.data.rooms
            };
        case actionTypes.MORE_ROOMS_RESULT:
            return {
                ...state,
                rooms: [...state.rooms, ...action.data.rooms],
            };
        case actionTypes.USER_LOGOUT:
            return initialState;
        default:
            return state;
    }
};
export const actions = {
    LIST_ROOMS: () => ({ type: actionTypes.LIST_ROOMS}),
    LIST_ROOMS_RESULT: userData => ({ type: actionTypes.LIST_ROOMS_RESULT, payload: userData }),
    MORE_ROOMS_RESULT: userData => ({ type: actionTypes.MORE_ROOMS_RESULT, payload: userData }),
    USER_LOGOUT: () => ({ type: actionTypes.USER_LOGOUT}),
  };
  
  export function* saga() {
  }
  