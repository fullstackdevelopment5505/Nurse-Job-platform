import Actions from "../variables/actions/Actions";

const initialState = {
    people: [],
    picture: null
};

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case Actions.SELECTION_SET_PEOPLE:
            return {
                ...state, people: action.people,
            };
        case Actions.SELECTION_SET_PICTURE:
            return {
                ...state, picture: action.picture,
            };
        default:
            return state;
    }
};

export default reducer;
