import Views from "../variables/Views";
import View from "../variables/actions/View";
import Actions from "../variables/actions/Actions";
import User from "../variables/actions/User";
export const actionTypes = {
    SHOW_HOME:'SHOW_HOME',
    CREATE_ROOM_RESULT:'CREATE_ROOM_RESULT',
    JOIN_ROOM_RESULT:'JOIN_ROOM_RESULT',
    RTC_SESSION_ACCEPTED:'RTC_SESSION_ACCEPTED',
    SEARCH:'SEARCH',
    NAVIGATE:'NAVIGATE',
    RTC_OUTGOING:'RTC_OUTGOING',
    RTC_INCOMING:'RTC_INCOMING',
    RTC_TERMINATED:'RTC_TERMINATED',
    USER_LOGOUT:'USER_LOGOUT',
};
const initialState = {
    nav: Views.CHAT,
    navBackup: Views.CHAT,
    main: Views.WELCOME,
    mainBackup: Views.WELCOME,
    panel: Views.CHAT,
    panelBackup: Views.CHAT,
    details: Views.DETAILS,
    mobile: Views.WELCOME,
};

export const apiViewReducer = (state = initialState, action) => {
    switch (action.type) {
        case actionTypes.SHOW_HOME:
            return {
                ...state, main: Views.WELCOME, mobile: Views.WELCOME,
            };
        case actionTypes.CREATE_ROOM_RESULT:
        case actionTypes.JOIN_ROOM_RESULT:
            return {
                ...state, main: Views.ROOM, mainBackup: Views.ROOM, mobile: Views.ROOM
            };
        case actionTypes.RTC_SESSION_ACCEPTED:
            return {
                ...state, main: Views.SESSION, mobile: Views.SESSION, nav: Views.SESSION,
            };
        case actionTypes.NAVIGATE:
            const { nav } = action;
            if ([Views.SESSION, Views.INCOMING, Views.OUTGOING, Views.DETAILS].includes(nav))
                return {
                    ...state, nav, mobile: nav, main: nav,
                };
            return {
                ...state, nav, panel: nav, mobile: Views.PANEL,
            };
        case actionTypes.SEARCH:
            if ([Views.CREATE_GROUP, Views.EDIT_GROUP, Views.RTC_GROUP_CREATE, Views.RTC_GROUP_ADD, Views.ADMIN].includes(state.panel)) return state;
            return {
                ...state,
                panel: Views.SEARCH,
                panelBackup: state.panel === Views.SEARCH ? state.panelBackup : state.panel,
                nav: Views.SEARCH,
                navBackup: state.panel === Views.SEARCH ? state.navBackup : state.nav,
            };
        case actionTypes.RTC_OUTGOING:
            return {
                ...state, main: Views.OUTGOING, mobile: Views.OUTGOING, nav: Views.OUTGOING,
            };
        case actionTypes.RTC_INCOMING:
            return {
                ...state, main: Views.INCOMING, mobile: Views.INCOMING, nav: Views.INCOMING,
            };
        case actionTypes.RTC_TERMINATED:
            return {
                ...state, main: state.mainBackup, mobile: state.mainBackup,
            };
        case actionTypes.USER_LOGOUT:
            return initialState;
        default:
            return state;
    }
}
export const actions = {
    // sendMsg:    
    showHome: () => ({ type: actionTypes.SHOW_HOME}),
    createRoomResult: () => ({ type: actionTypes.CREATE_ROOM_RESULT}),
    joinRoomResult: () => ({ type: actionTypes.JOIN_ROOM_RESULT}),
    rtcSessionAccepted: () => ({ type: actionTypes.RTC_SESSION_ACCEPTED}),
    navigate: () => ({ type: actionTypes.NAVIGATE}),
    search: () => ({ type: actionTypes.SEARCH}),
    rtcOutGoing: () => ({ type: actionTypes.RTC_OUTGOING}),
    rtcInComing: () => ({ type: actionTypes.RTC_INCOMING}),
    rtcTerminated: () => ({ type: actionTypes.RTC_TERMINATED}),
    userLogout: () => ({ type: actionTypes.USER_LOGOUT}),
  };
  
  export function* saga() {
  }