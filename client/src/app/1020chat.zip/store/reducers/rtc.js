import Actions from "../variables/actions/Actions";
import Sip from "../variables/Sip";
import moment from "moment";
import User from "../variables/actions/User";
import Views from "../variables/Views";
export const actionTypes = {
    RTC_SCREEN_SHARE: "RTC_SCREEN_SHARE",
    RTC_SCREEN_SHARE_STOP: "RTC_SCREEN_SHARE_STOP",
    RTC_PEER_CONNECTION: "RTC_PEER_CONNECTION",
    RTC_OUTGOING: "RTC_OUTGOING",
    RTC_INCOMING: "RTC_INCOMING",
    RTC_ENTER: "RTC_ENTER",
    RTC_EXIT:'RTC_EXIT',
    RTC_LOCAL_STREAM:'RTC_LOCAL_STREAM',
    RTC_SESSION_ACCEPTED:'RTC_SESSION_ACCEPTED',
    RTC_REMOTE_ADD_AUDIO_STREAM:'RTC_REMOTE_ADD_AUDIO_STREAM',
    RTC_REMOTE_ADD_VIDEO_STREAM:'RTC_REMOTE_ADD_VIDEO_STREAM',
    RTC_REMOTE_REMOVE_VIDEO_STREAM:'RTC_REMOTE_REMOVE_VIDEO_STREAM',
    RTC_SETUP_LISTENERS:'RTC_SETUP_LISTENERS',
    RTC_CALL:'RTC_CALL',
    RTC_SET_COUNTERPART:'RTC_SET_COUNTERPART',
    RTC_OFFER:'RTC_OFFER',
    RTC_SWITCH_VIDEO:'RTC_SWITCH_VIDEO',
    RTC_SWITCH_AUDIO:'RTC_SWITCH_AUDIO',
    RTC_SWITCHED_PEER_VIDEO:'RTC_SWITCHED_PEER_VIDEO',
    RTC_SET_PEER_VIDEO:'RTC_SET_PEER_VIDEO',
    RTC_PEER_ADDED:'RTC_PEER_ADDED',
    RTC_TERMINATED:'RTC_TERMINATED',
    USER_LOGOUT:'USER_LOGOUT'
};
const initialState = {
    peerConnection: null,
    localStream: null,
    videoStreams: [],
    audioStreams: [],
    status: null,
    audio: true,
    video: true,

    room: null,
    user: null,
    pcs: {},
    streams: {},
    peers: [],
    peerVideo: {},
    muteCount: 0,

    screenSharing: false,
};

const removePeer = (array, element) => {
    let result = [...array];
    let i = 0;
    let found = false;
    while (i < result.length && !found) {
        if (element._id === array[i]._id) {
            result.splice(i, 1);
            found = true;
        }
        i++;
    }
    return result;
};

export const apirtcReducer = (state = initialState, action) => {
    switch (action.type) {
        case actionTypes.RTC_SCREEN_SHARE:
            return {
                ...state,
                screenSharing: true,
            };
        case actionTypes.RTC_SCREEN_SHARE_STOP:
            return {
                ...state,
                screenSharing: false,
            };
        case actionTypes.RTC_PEER_CONNECTION:
            return {
                ...state, pcs: {
                    ...state.pcs, [action.peer._id]: action.peerConnection,
                },
                peers: state.peers.includes(action.peer._id) ? state.peers : [...state.peers, action.peer._id],
            };
        case actionTypes.RTC_OUTGOING:
            return {
                ...state, user: action.user, room: action.room, status: Views.OUTGOING,
            };
        case actionTypes.RTC_INCOMING:
            return {
                ...state, user: action.user, room: action.room, status: Views.OUTGOING, peerVideo: action.peerVideo ? {...state.peerVideo, ...action.peerVideo} : state.peerVideo,
            };
        case actionTypes.RTC_ENTER:
            return {
                ...state, room: {
                    ...state.room,
                    peers: [...state.room.peers, action.peer],
                    ring: removePeer(state.room.ring, action.peer),
                },
            };
        case actionTypes.RTC_EXIT:
            let newPeers = [...state.peers];
            newPeers.splice(newPeers.indexOf(action.peer._id), 1);
            if (!state.room) return {
                ...state, peers: newPeers,
            };
            return {
                ...state,
                room: {
                    ...state.room,
                    exit: [...state.room.peers, action.peer],
                    ring: removePeer(state.room.ring, action.peer),
                    peers: removePeer(state.room.peers, action.peer),
                },
                peers: newPeers,
            };
        case actionTypes.RTC_LOCAL_STREAM:
            return {
                ...state, localStream: action.stream,
            };
        case actionTypes.RTC_SESSION_ACCEPTED:
            return {
                ...state,  status: Views.SESSION,
            };
        case actionTypes.RTC_REMOTE_ADD_AUDIO_STREAM:
            let isAudioStream = false;
            state.audioStreams.forEach(stream => {
                if (stream.getAudioTracks()[0].id === action.stream.getAudioTracks()[0].id) isAudioStream = true;
            });
            if (isAudioStream) return state;
            return {
                ...state, audioStreams: [...state.audioStreams, action.stream],
            };
        case actionTypes.RTC_REMOTE_ADD_VIDEO_STREAM:
            let isVideoStream = false;
            state.videoStreams.forEach(stream => {
                if (stream.getVideoTracks()[0].id === action.stream.getVideoTracks()[0].id) isVideoStream = true;
            });
            if (isVideoStream) return state;
            return {
                ...state, videoStreams: [...state.videoStreams, action.stream], remoteStream: state.isGroup ? action.stream : state.remoteStream,
                streams: { ...state.streams, [action.peer._id]: action.stream },
            };
        case actionTypes.RTC_REMOTE_REMOVE_VIDEO_STREAM:
            let newVideoStreams = [];
            state.videoStreams.forEach(stream => {
                if (stream.getVideoTracks()[0].id === action.stream.getVideoTracks()[0].id) return;
                newVideoStreams.push(stream);
            });
            return {
                ...state, videoStreams: newVideoStreams, streams: { ...state.streams, [action.peer._id]: null }
            };
        case actionTypes.RTC_SETUP_LISTENERS:
            return {
                ...state, peerConnection: action.peerConnection,
            };
        case actionTypes.RTC_CALL:
            return {
                ...state, status: Views.OUTGOING, video: action.video,
            };
        case actionTypes.RTC_SET_COUNTERPART:
            return {
                ...state, user: action.user,
            };
        case actionTypes.RTC_OFFER:
            return state;
        case actionTypes.RTC_SWITCH_VIDEO:
            return {
                ...state, video: action.video,
            };
        case actionTypes.RTC_SWITCH_AUDIO:
            return {
                ...state, audio: action.audio,
            };
        case actionTypes.RTC_SWITCHED_PEER_VIDEO:
            return {
                ...state, muteCount: state.muteCount + 1,
            };
        case actionTypes.RTC_SET_PEER_VIDEO:
            return {
                ...state, peerVideo: { ...state.peerVideo, [action.peer._id]: action.video },
            };
        case actionTypes.RTC_PEER_ADDED:
            return {
                ...state, room: { ...state.room, ring: [...state.room.ring, action. peer] }
            };
        case actionTypes.RTC_TERMINATED:
        case actionTypes.USER_LOGOUT:
            return initialState;
        default:
            return state;
    }
};
export const actions = {
    rtcScreenShare: userData => ({ type: actionTypes.RTC_SCREEN_SHARE, payload: userData }),
    rtcScreenShareStop: userData => ({ type: actionTypes.RTC_SCREEN_SHARE_STOP, payload: userData }),
    rtcPeerConnection: userData => ({ type: actionTypes.RTC_PEER_CONNECTION, payload: userData }),
    rtcOoutgoing: userData => ({ type: actionTypes.RTC_OUTGOING, payload: userData }),
    rtcIncoming: userData => ({ type: actionTypes.RTC_INCOMING, payload: userData }),
    rtcEnter: userData => ({ type: actionTypes.RTC_ENTER, payload: userData }),
    rtcExit: userData => ({ type: actionTypes.RTC_EXIT, payload: userData }),
    rtcLocalStream: userData => ({ type: actionTypes.RTC_LOCAL_STREAM, payload: userData }),
    rtcSessionAccepted: userData => ({ type: actionTypes.RTC_SESSION_ACCEPTED, payload: userData }),
    rtcRemoteAddAudioStream: userData => ({ type: actionTypes.RTC_REMOTE_ADD_AUDIO_STREAM, payload: userData }),
    rtcRemoteAddVideoStream: userData => ({ type: actionTypes.RTC_REMOTE_ADD_VIDEO_STREAM, payload: userData }),
    rtcRemoteRemoveVideoStream: userData => ({ type: actionTypes.RTC_REMOTE_REMOVE_VIDEO_STREAM, payload: userData }),
    rtcSetupListeners: userData => ({ type: actionTypes.RTC_SETUP_LISTENERS, payload: userData }),
    rtcCall: userData => ({ type: actionTypes.RTC_CALL, payload: userData }),
    rtcSetCounterpart: userData => ({ type: actionTypes.RTC_SET_COUNTERPART, payload: userData }),
    rtcOffer: userData => ({ type: actionTypes.RTC_OFFER, payload: userData }),
    rtcSwitchVideo: userData => ({ type: actionTypes.RTC_SWITCH_VIDEO, payload: userData }),
    rtcSwitchAudio: userData => ({ type: actionTypes.RTC_SWITCH_AUDIO, payload: userData }),
    rtcSwitchedPeerVideo: userData => ({ type: actionTypes.RTC_SWITCHED_PEER_VIDEO, payload: userData }),
    rtcSetPeerVideo: userData => ({ type: actionTypes.RTC_SET_PEER_VIDEO, payload: userData }),
    rtcPeerAdded: userData => ({ type: actionTypes.RTC_PEER_ADDED, payload: userData }),
    userLogout: () => ({ type: actionTypes.USER_LOGOUT}),
    rtcTerminated: () => ({ type: actionTypes.RTC_TERMINATED}),
  };
  
  export function* saga() {
  }