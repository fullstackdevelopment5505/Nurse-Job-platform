import jwtDecode from 'jwt-decode';
import { connect } from "react-redux";

import { ioSaga } from '../sagas/io';
export const actionTypes = {
    TOGGLE_FAVORITE_RESULT: "TOGGLE_FAVORITE_RESULT",
    LIST_FAVORITES_RESULT: "LIST_FAVORITES_RESULT",
    USER_LOGIN:'USER_LOGIN',
    LIST_ROOM:'LIST_ROOM',
    USER_REGISTER:'USER_REGISTER',
    USER_LOGIN_SUCCESS:'USER_LOGIN_SUCCESS',
    USER_LOGOUT:'USER_LOGOUT',
    CHANGE_PICTURE_RESULT:'CHANGE_PICTURE_RESULT',
    SEND_MSG:'SEND_MSG'
};
const initialApiUserState = {
    favorites: [],
    login: {},
    register: {},
};

export const apiuserReducer = (state = initialApiUserState, action) => {
    switch (action.type) {
        case actionTypes.SEND_MSG:
            return {
                ...state, msg: action.data
            };
        case actionTypes.TOGGLE_FAVORITE_RESULT:
            var roomID = action.payload['roomID']
            window.socket.emit('toggle-favorite',  roomID );
            return {
                ...state, favorites: action.data.favorites
            };
        case actionTypes.LIST_FAVORITES_RESULT:
            window.socket.emit('list-favorites');
            return {
                ...state, favorites: action.data.favorites
            };
        case actionTypes.USER_LOGIN:
            return {
                ...state, login: {},
            };
        case actionTypes.USER_REGISTER:
            return {
                ...state, register: {},
            };
        case actionTypes.USER_LOGIN_SUCCESS:

            const user = jwtDecode(action.payload.token);
            if (action.keep) localStorage.setItem('token', action.payload.token);
            ioSaga(action);
            return {
                ...state, ...action.user, user, token:action.payload.token, keep: false , login: {}, register: {},
            };
        case actionTypes.LIST_ROOM:
            return window.socket.emit('list-rooms', {});
            // return state;
        case actionTypes.SEND_MSG:
            sendMessage(action.payload)
        case actionTypes.USER_LOGOUT:
            return initialApiUserState;
        case actionTypes.CHANGE_PICTURE_RESULT:
            window.socket.emit('change-picture', { imageID: action.image._id });
            return {
                ...state, picture: action.data.picture
            };
        default:
            return state;
    }
}
const sendMessage = ({ roomID, authorID, content, contentType, fileID }) => {
    window.socket.emit('message', { roomID, authorID, content, type: contentType, fileID });
};
export const actions = {
    listRoom: ()=>({ type: actionTypes.LIST_ROOM}),
    sendMsg: userData => ({ type: actionTypes.SEND_MSG, payload: userData }), 
    ToggleFavoriteResult: userData => ({ type: actionTypes.TOGGLE_FAVORITE_RESULT, payload: userData }),
    ListFavoritesResult: userData => ({ type: actionTypes.LIST_FAVORITES_RESULT, payload: userData }),
    userLogin: userData => ({ type: actionTypes.USER_LOGIN, payload: userData }),
    userRegister: userData => ({ type: actionTypes.USER_REGISTER, payload: userData }),
    userLoginSuccess: userData => ({ type: actionTypes.USER_LOGIN_SUCCESS, payload: userData }),
    changePictureResult: userData => ({ type: actionTypes.CHANGE_PICTURE_RESULT, payload: userData }),
    userLogout: () => ({ type: actionTypes.USER_LOGOUT}),
  };
  
  export function* saga() {
  }