import { call, fork, put, select, take } from "redux-saga/effects";
import { eventChannel } from 'redux-saga';
import axios from "axios";
import Actions from "../variables/actions/Actions";
import Config from '../config';

const upload = (image, token, crop, onProgress) => {
    const url = (Config.url || '') + '/api/upload';

    const data = new FormData();

    data.append('image', image, image.name);
    data.append('crop', crop);

    const config = {
        onUploadProgress: onProgress,
        withCredentials: true,
        headers: {'Authorization': "Bearer " + token},
    };

    return axios.post(url, data, config);
};

const createUploader = (image, token, crop) => {

    let emit;
    const chan = eventChannel(emitter => {

        emit = emitter;
        return () => {};
    });

    const uploadPromise = upload(image, token, crop, (event) => {
        if (event.loaded.total === 1) {
            emit(Actions.UPLOAD_END);
        }

        emit(event.loaded.total || -1);
    });

    return [ uploadPromise, chan ];
};

const getToken = state => state.user.token;

function* watchOnProgress(chan, ref) {
    while (true) {
        const data = yield take(chan);
        yield put({ type: Actions.UPLOAD_PROGRESS, data, ref });
    }
}

export function* uploadSaga(action) {
    const image = action.image;
    const token = yield select(getToken);
    const [ uploadPromise, chan ] = createUploader(image, token, action.crop);
    yield fork(watchOnProgress, chan, action.ref);

    try {
        const result = yield call(() => uploadPromise);
        yield put({ type: Actions.UPLOAD_SUCCESS, result, ref: action.ref });
        if (action.next) yield put(action.next);
    } catch (err) {
        yield put({ type: Actions.UPLOAD_ERROR, err: err.response, ref: action.ref });
    }
}

