import { eventChannel } from 'redux-saga';
import { call, put, take } from "redux-saga/effects";
import io from 'socket.io-client';
import Actions from "../variables/actions/Actions";
import moment from "moment";
import View from "../variables/actions/View";
import Views from "../variables/Views";
import * as UIkit from "uikit";
// import Config from "../config";
const ioConnect = token => {
  // const socket = io((Config.url || '') + '/');
  const socket = io('/');
  window.socket = socket;
  return new Promise(resolve => {
    socket.on('connect', () => {
      socket.emit('authenticate', {token});
      resolve(socket);
    });
  });
};

function ioSubscribe(socket) {
  return eventChannel(emit => {
    socket.on('authenticated', () => {
      window.socket.emit('list-rooms', {});
      window.socket.emit('list-favorites', {});
      window.socket.emit('list-status');
      window.socket.emit('online');
      if (!window.firstSearch) {
        window.firstSearch = true;
        window.socket.emit('search', { search: '' });
      }
      if (!window.isMobile) window.socket.emit('available');
      if (window.disconnected) {
        window.disconnected = false;
        UIkit.notification('Reconnected to server.', {status: 'success'});
      }
    });
    socket.on('disconnect', () => {
      if (window.logout) {
        window.logout = false;
      }
      else {
        window.disconnected = true;
        UIkit.notification('Connection lost. Trying to reconnect...', {status: 'danger'});
      }
    });
    socket.on('search', data => {
      emit({ type: Actions.SEARCH_RESULT, data });
    });
    socket.on('list-rooms', data => {
      emit({ type: Actions.LIST_ROOMS_RESULT, data });
      console.log('list-rooms', data);
    });
    socket.on('create-room', data => {
      emit({ type: Actions.CREATE_ROOM_RESULT, data });
      console.log('create-room', data);
    });
    socket.on('join-room', data => {
      emit({ type: Actions.JOIN_ROOM_RESULT, data });
      console.log('join-room', data);
    });
    socket.on('message-in', data => {
      console.log('message-in', data);
      emit({ type: Actions.ADD_MESSAGE, message: data.message });
      emit({ type: Actions.SOUNDS_MESSAGE });
      window.socket.emit('list-rooms', {});
    });
    socket.on('message-out', data => {
      console.log('message-out', data);
      window.socket.emit('list-rooms', {});
    });
    socket.on('list-favorites', data => {
      console.log('list-favorites', data);
      emit({ type: Actions.LIST_FAVORITES_RESULT, data });
    });
    socket.on('toggle-favorite', data => {
      console.log('toggle-favorite', data);
      emit({ type: Actions.TOGGLE_FAVORITE_RESULT, data });
    });
    socket.on('change-picture', data => {
      console.log('change-picture', data);
      emit({ type: Actions.CHANGE_PICTURE_RESULT, data });
    });
    socket.on('more-messages', data => {
      console.log('more-messages', data);
      emit({ type: Actions.MORE_MESSAGES_RESULT, data });
    });
    socket.on('more-images', data => {
      console.log('more-images', data);
      emit({ type: Actions.MORE_IMAGES_RESULT, data });
    });
    socket.on('more-rooms', data => {
      console.log('more-rooms', data);
      emit({ type: Actions.MORE_ROOMS_RESULT, data });
    });
    socket.on('get-user', data => {
      console.log('get-user', data);
      emit({ type: Actions.RTC_GET_USER_RESULT, data });
    });
    socket.on('video-status', data => {
      console.log('video-status', data);
      emit({ type: Actions.RTC_REMOTE_VIDEO_STATUS_RESULT, data });
    });
    socket.on('rtc', data => {
      console.log('rtc', data);
      switch (data.event) {
        case 'ringing':
          window.busy = true;
          window.socket.emit('busy');
          emit({type: Actions.RTC_OUTGOING, room: data.room, user: data.room.ring[0]});
          emit({type: Actions.SOUNDS_RING});
          break;
        case 'ring':
          window.busy = true;
          window.socket.emit('busy');
          emit({type: Actions.RTC_INCOMING, room: data.room, user: data.sender, peerVideo: data.peerVideo});
          emit({type: Actions.RTC_SET_PEER_VIDEO, peer: data.sender, video: data.video, peerVideo: data.peerVideo});
          emit({type: Actions.SOUNDS_RING});
          break;
        case 'peer-video':
          emit({type: Actions.RTC_SET_PEER_VIDEO, peer: data.sender, video: data.video});
          break;
        case 'enter':
          emit({type: Actions.RTC_SET_PEER_VIDEO, peer: data.sender, video: data.video});
          emit({type: Actions.RTC_ENTER, peer: data.sender});
          emit({type: Actions.SOUNDS_STOP});
          break;
        case 'exit':
          emit({type: Actions.RTC_EXIT, peer: data.sender});
          emit({type: Actions.RTC_CLOSE, emitted: true, peer: data.sender});
          break;
        case 'answer':
          emit({type: Actions.RTC_REMOTE_DESC, answer: data.answer, peer: data.sender});
          break;
        case 'offer':
          emit({type: Actions.RTC_OFFER, offer: data.offer, peer: data.sender});
          break;
        case 'ice-candidate':
          emit({type: Actions.RTC_CANDIDATE, candidate: data.candidate, peer: data.sender});
          break;
        case 'switch-video':
          emit({type: Actions.RTC_SWITCH_PEER_VIDEO, video: data.video, peer: data.sender});
          break;
        case 'peer-added':
          emit({type: Actions.RTC_PEER_ADDED, peer: data.peer});
          break;
      }
    });
    socket.on('list-status', data => {
      console.log('list-status', data);
      emit({ type: Actions.STATUS_LIST, data });
    });
    socket.on('online', data => {
      console.log('online', data);
      emit({ type: Actions.STATUS_ONLINE, data });
    });
    socket.on('offline', data => {
      console.log('offline', data);
      emit({ type: Actions.STATUS_OFFLINE, data });
    });
    socket.on('busy', data => {
      console.log('busy', data);
      emit({ type: Actions.STATUS_BUSY, data });
    });
    socket.on('away', data => {
      console.log('away', data);
      emit({ type: Actions.STATUS_AWAY, data });
    });
    socket.on('available', data => {
      console.log('available', data);
      emit({ type: Actions.STATUS_AVAILABLE, data });
    });
    socket.on('create-group', data => {
      console.log('create-group', data);
      emit({type: View.NAVIGATE, nav: Views.CHAT});
      emit({type: Actions.SEND_MESSAGE, roomID: data.room._id, authorID: data.user, content: `New group created: ${data.room.title}`, contentType: 'info'});
      emit({type: Actions.LIST_ROOMS});
      emit({type: Actions.JOIN_ROOM, roomID: data.room._id});
    });
    return () => {};
  });
}

// worker saga: makes the api call when watcher saga sees the action
export function* ioSaga(action) {
  console.log('iosaga')
  const socket = yield call(ioConnect, action.token);

  const channel = yield call(ioSubscribe, socket);
  while (true) {
    let action = yield take(channel);
    yield put(action);
  }
}
