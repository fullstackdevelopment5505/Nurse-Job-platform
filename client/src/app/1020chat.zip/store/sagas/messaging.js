import {call, put, select} from "redux-saga/effects";
import jwtDecode from 'jwt-decode';
import User from "../variables/actions/User";

import axios from "axios";
import Actions from "../variables/actions/Actions";
import moment from "moment";

const sendMessage = ({ roomID, authorID, content, contentType, fileID }) => {
    window.socket.emit('message', { roomID, authorID, content, type: contentType, fileID });
};

// worker saga: makes the api call when watcher saga sees the action
export function* sendMessageSaga(action) {
    yield call(sendMessage, action);
}

export function* sendImageSaga(action) {
    const {image} = yield select(state => state.images[action.ref]);
    const user = yield select(state => state.user);

    yield put({type: Actions.SEND_MESSAGE, roomID: action.target, authorID: user.id, content: image.shieldedID, contentType: 'image'});
    yield put({type: Actions.ADD_MESSAGE, message: {
            _id: Math.random(), author: {...user, _id: user.id}, content: image.shieldedID, type: 'image', date: moment()
        }});
}
