import {call, put, select, take} from "redux-saga/effects";
import {eventChannel} from "redux-saga";
import Actions from "../variables/actions/Actions";
import Config from "../config";
import * as UIkit from "uikit";

const configuration = {
    iceServers: Config.iceServers,
};

const getSelf = user => ({
    _id: user.id,
    username: user.username,
    firstName: user.firstName,
    lastName: user.lastName,
    picture: user.picture,
});

const createRoom = (self, users, group, video) => {
    window.socket.emit('rtc', { event: 'room', sender: self, users, isGroup: !!group, group, video });
};

const enterRoom = (self, roomId, video) => {
    window.socket.emit('rtc', { event: 'enter', sender: self, roomId, video });
};

const exitRoom = (self, roomId) => {
    window.socket.emit('rtc', { event: 'exit', sender: self, roomId });
};

const setupListeners = (peerConnection, user, sender, video) => {
    console.log(`setting up listeners for PeerConnection with ${user.firstName} ${user.lastName}`);
    return eventChannel(emit => {
        peerConnection.addEventListener('icecandidate', event => {
            console.log('icecandidate', event);
            if (event.candidate) {
                window.socket.emit('rtc', { event: 'ice-candidate', candidate: event.candidate, user, sender });
            }
        });
        peerConnection.addEventListener('connectionstatechange', event => {
            console.log('connectionstatechange', event);
            switch(peerConnection.connectionState) {
                case "new":
                    break;
                case "connected":
                    emit({ type: Actions.RTC_SESSION_ACCEPTED });
                    break;
                case "disconnected":
                    emit({type: Actions.RTC_EXIT, peer: sender});
                    emit({ type: Actions.RTC_CLOSE, emitted: true, peer: user });
                    break;
                case "closed":
                    emit({type: Actions.RTC_EXIT, peer: sender});
                    emit({ type: Actions.RTC_CLOSE, emitted: true, peer: user });
                    break;
                case "failed":
                    emit({type: Actions.RTC_EXIT, peer: sender});
                    emit({ type: Actions.RTC_CLOSE, emitted: true, peer: user });
                    break;
                default:
                    break;
            }
        });
        peerConnection.addEventListener('track', async event => {
            console.log('track', event);
            const track = event.track;
            const stream = new MediaStream();
            stream.addTrack(track);

            if (track.kind === 'audio') {
                emit({type: Actions.RTC_REMOTE_ADD_AUDIO_STREAM, stream});
            } else {
                if (stream.getVideoTracks().length > 0) stream.getVideoTracks()[0].enabled = video;

                track.onmute = () => emit({type: Actions.RTC_REMOTE_REMOVE_VIDEO_STREAM, stream, peer: user});
                track.onunmute = () => emit({type: Actions.RTC_REMOTE_ADD_VIDEO_STREAM, stream, peer: user});

                if (!track.muted) emit({type: Actions.RTC_REMOTE_ADD_VIDEO_STREAM, stream, peer: user});
            }
        });
        return () => {};
    });
};

const sendOffer = async (peerConnection, user, sender, stream) => {
    if (!window.senders) window.senders = {};
    window.senders[user._id] = [];
    for (const track of stream.getTracks()) {
        const sender = await peerConnection.addTrack(track);
        window.senders[user._id].push(sender);
    }
    const offer = await peerConnection.createOffer();
    await peerConnection.setLocalDescription(offer);
    window.socket.emit('rtc', { event: 'offer', offer, user, sender });
    return peerConnection;
};

const sendAnswer = async (peerConnection, user, sender, stream, offer) => {
    if (!window.senders) window.senders = {};
    window.senders[user._id] = [];
    for (const track of stream.getTracks()) {
        const sender = await peerConnection.addTrack(track);
        window.senders[user._id].push(sender);
    }
    await peerConnection.setRemoteDescription(new RTCSessionDescription(offer));
    const answer = await peerConnection.createAnswer();
    await peerConnection.setLocalDescription(answer);
    window.socket.emit('rtc', { event: 'answer', answer, user, sender });
    return peerConnection;
};

const setRemoteDescription = async (peerConnection, answer) => {
    const remoteDesc = new RTCSessionDescription(answer);
    await peerConnection.setRemoteDescription(remoteDesc);
    return peerConnection;
};

export function* createRoomSaga(action) {
    const stream = yield call(getUserMedia, action.video, action.audio);
    if (!stream) {
        yield put({ type: Actions.RTC_CLOSE });
        return;
    }
    if (stream.getVideoTracks().length > 0) stream.getVideoTracks()[0].enabled = action.video;
    yield put({ type: Actions.RTC_SWITCH_VIDEO, video: action.video });
    yield put({ type: Actions.RTC_SWITCH_AUDIO, audio: action.audio });
    yield put({ type: Actions.RTC_LOCAL_STREAM, stream });
    const user = yield select(state => state.user);
    const self = getSelf(user);
    yield call(createRoom, self, action.users, action.group, action.video);
}

export function* enterRoomSaga(action) {
    const user = yield select(state => state.user);
    const self = getSelf(user);
    yield call(enterRoom, self, action.roomId, action.video);
}

export function* terminatedSaga(action) {
    window.busy = false;
    window.socket.emit('online');
    yield put({ type: Actions.SOUNDS_STOP });
}

export function* closeSaga(action) {
    const pcs = yield select(state => state.rtc.pcs);
    const room = yield select(state => state.rtc.room);
    const peers = yield select(state => state.rtc.peers);
    const streams = yield select(state => state.rtc.streams);
    console.log('close peers', peers)
    if (peers.length > 0 && action.emitted) {
        console.log('emitted', peers)
        let peerConnection = pcs[action.peer._id];
        if (peerConnection && peerConnection.connectionState !== 'closed') peerConnection.close();
        if (streams[action.peer._id]) yield put({type: Actions.RTC_REMOTE_REMOVE_VIDEO_STREAM, stream: streams[action.peer._id], peer: action.peer});
        return;
    }
    const localStream = yield select(state => state.rtc.localStream);
    Object.keys(pcs).forEach(key => {
        let peerConnection = pcs[key];
        if (peerConnection && peerConnection.connectionState !== 'closed') peerConnection.close();
    });
    // const user = yield select(state => state.rtc.user);
    // if (peerConnection && peerConnection.connectionState !== 'closed') peerConnection.close();
    if (localStream) localStream.getTracks().forEach(track => track.stop());
    const user = yield select(state => state.user);
    const self = getSelf(user);
    if (!action.emitted && room) yield call(exitRoom, self, room.id);
    yield put({ type: Actions.RTC_TERMINATED });
}

export function* acceptSaga(action) {
    const stream = yield call(getUserMedia, action.video, action.audio);
    if (!stream) {
        yield put({ type: Actions.RTC_CLOSE });
        return;
    }
    if (stream.getVideoTracks().length > 0) stream.getVideoTracks()[0].enabled = action.video;
    yield put({ type: Actions.RTC_SWITCH_VIDEO, video: action.video });
    yield put({ type: Actions.RTC_SWITCH_AUDIO, audio: action.audio });
    yield put({ type: Actions.RTC_LOCAL_STREAM, stream });
    const room = yield select(state => state.rtc.room);
    yield put({ type: Actions.RTC_ROOM_ENTER, roomId: room.id, video: action.video });
    yield put({ type: Actions.SOUNDS_STOP });
}

export function* setupListenersSaga(action) {
    const video = yield select(state => state.rtc.peerVideo[action.peer._id]);
    const channel = yield call(setupListeners, action.peerConnection, action.peer, action.sender, video);

    while (true) {
        let action = yield take(channel);
        yield put(action);
    }
}

export function* initConnectionSaga(action) {
    const stream = yield select(state => state.rtc.localStream);
    const video = yield select(state => state.rtc.video);

    const user = yield select(state => state.user);
    const sender = getSelf(user);

    window.socket.emit('rtc', { event: 'peer-video', sender, video, user: action.peer });

    const peerConnection = new RTCPeerConnection(configuration);
    yield put({ type: Actions.RTC_SETUP_LISTENERS, peerConnection, peer: action.peer, sender });
    yield call(sendOffer, peerConnection, action.peer, sender, stream);

    yield put({ type: Actions.RTC_PEER_CONNECTION, peerConnection, peer: action.peer });
}

export function* answerSaga(action) {
    const stream = yield select(state => state.rtc.localStream);
    const user = yield select(state => state.user);
    const sender = getSelf(user);

    const peerConnection = new RTCPeerConnection(configuration);
    yield put({ type: Actions.RTC_SETUP_LISTENERS, peerConnection, peer: action.peer, sender });
    yield call(sendAnswer, peerConnection, action.peer, sender, stream, action.offer);

    yield put({ type: Actions.RTC_PEER_CONNECTION, peerConnection, peer: action.peer });
}

export function* setRemoteDescriptionSaga(action) {
    const peerConnection = yield select(state => state.rtc.pcs[action.peer._id]);
    yield call(setRemoteDescription, peerConnection, action.answer);
}

export function* gotCandidateSaga(action) {
    const peerConnection = yield select(state => state.rtc.pcs[action.peer._id]);

    const gotCandidate = (peerConnection, candidate) => {
        try {
            peerConnection.addIceCandidate(candidate);
        }
        catch (e) {
            console.log('candidate error', e);
        }
    };

    const checkCandidate = () => {
        if (peerConnection && peerConnection.connectionState !== 'closed' && peerConnection.currentRemoteDescription) gotCandidate(peerConnection, action.candidate);
        // else setTimeout(checkCandidate, 100);
    };

    checkCandidate();
}

const getUserMedia = async (video, audio) => {
    let result;
    if (video) {
        const constraints = {
            video: true, audio: audio ? {echoCancellation: true} : false,
        };
        try {
            result = await navigator.mediaDevices.getUserMedia(constraints);
        }
        catch (e) {
            console.log('get local video failed');
            UIkit.notification('Could not get local video. Check your camera!', {status: 'danger'});
            return null;
        }
        return result;
    }
    if (!video) {
        let constraints = {
            video: true, audio: audio ? {echoCancellation: true} : false,
        };
        try {
            result = await navigator.mediaDevices.getUserMedia(constraints);
        } catch (e) {
            console.log('get local video failed');
            UIkit.notification('Could not get local video. This session will only have local audio.', {status: 'info'});
            constraints.video = false;
            console.log('trying audio');
            try {
                result = await navigator.mediaDevices.getUserMedia(constraints);
            } catch (e) {
                console.log('get local audio failed');
                UIkit.notification('Could not get local audio. Check your microphone!', {status: 'danger'});
                return null;
            }
        }
        return result;
    }
};

// worker saga: makes the api call when watcher saga sees the action
export function* switchVideo(action) {
    const localStream = yield select(state => state.rtc.localStream);
    if (!localStream) return;
    const pcs = yield select(state => state.rtc.pcs);
    const user = yield select(state => state.user);
    const sender = getSelf(user);

    localStream.getVideoTracks().forEach(track => track.enabled = !!action.video);

    Object.keys(pcs).forEach(async userID => {
        window.socket.emit('rtc', { event: 'switch-video', video: !!action.video, user: {_id: userID}, sender });
        console.log('switch video emit', { event: 'switch-video', video: !!action.video, user: {_id: userID}, sender })
    });
}

export function* switchAudio(action) {
    const localStream = yield select(state => state.rtc.localStream);
    if (!localStream) return;
    localStream.getAudioTracks().forEach(track => track.enabled = !!action.audio);
}

export function* switchPeerVideo(action) {
    const pcs = yield select(state => state.rtc.pcs);

    const receivers = pcs[action.peer._id].getReceivers();

    for (let receiver of receivers) {
        if (receiver.track.kind === 'video') receiver.track.enabled = action.video;
    }

    yield put({ type: Actions.RTC_SET_PEER_VIDEO, peer: action.peer, video: action.video });
    yield put({ type: Actions.RTC_SWITCHED_PEER_VIDEO });
}

export function* addPeers(action) {
    const video = yield select(state => state.rtc.video);
    const room = yield select(state => state.rtc.room);
    const user = yield select(state => state.user);
    const peerVideo = yield select(state => state.peerVideo);
    const self = getSelf(user);
    window.socket.emit('rtc', { event: 'add-peer', sender: self, users: action.users, video, roomId: room.id, peerVideo });
}

function startCapture(displayMediaOptions) {
    let captureStream = null;

    return navigator.mediaDevices.getDisplayMedia(displayMediaOptions)
        .catch(err => { console.error("Error:" + err); return null; });
}

export function* screenShare(action) {
    const stream = yield call(startCapture, {cursor: true});
    if (!stream) {
        UIkit.notification('Could not not get screen! Screen share not started.', {status: 'danger'});
        yield put({type: Actions.RTC_SCREEN_SHARE_STOP});
        return;
    }
    const pc = yield select(state => state.rtc.peerConnection);
    const localStream = yield select(state => state.rtc.localStream);

    const sender = pc.getSenders().find(s => {
        return s.track.kind === 'video';
    });
    console.log('found sender:', sender);
    sender.replaceTrack(stream.getVideoTracks()[0]);
    localStream.removeTrack(localStream.getVideoTracks()[0]);
    localStream.addTrack(stream.getVideoTracks()[0]);
}

function getVideo(mediaOptions) {
    return navigator.mediaDevices.getUserMedia(mediaOptions)
        .catch(err => { console.error("Error:" + err); return null; });
}

export function* stopScreenShare(action) {
    const stream = yield call(getVideo, {video: true});
    const pc = yield select(state => state.rtc.peerConnection);
    const localStream = yield select(state => state.rtc.localStream);

    const sender = pc.getSenders().find(s => {
        return s.track.kind === 'video';
    });
    console.log('found sender:', sender);
    sender.replaceTrack(stream.getVideoTracks()[0]);
    localStream.removeTrack(localStream.getVideoTracks()[0]);
    localStream.addTrack(stream.getVideoTracks()[0]);
}
