import { call, put, select } from "redux-saga/effects";
import jwtDecode from 'jwt-decode';
import User from "../variables/actions/User";

import axios from "axios";
import Actions from "../variables/actions/Actions";
import Config from "../config";

const postLogin = (email, password) => {
  return axios({
    method: "post",
    url: (Config.url || '') + "/api/login",
    data: { email, password }
  });
};

const listFavorites = () => {
  window.socket.emit('list-favorites');
};

const toggleFavorite = roomID => {
  window.socket.emit('toggle-favorite', { roomID });
};

const changePicture = image => {
  window.socket.emit('change-picture', { imageID: image._id });
};

const postRegister = data => {
  return axios({
    method: "post",
    url: (Config.url || '') + "/api/register",
    data
  });
};

// worker saga: makes the api call when watcher saga sees the action
export function* loginSaga(action) {
  try {
    const response = yield call(postLogin, action.email, action.password);
    const token = response.data.token;

    const user = jwtDecode(token);

    if (action.keep) localStorage.setItem('token', token);

    // dispatch a success action to the store
    yield put({ type: User.USER_LOGIN_SUCCESS, user, token, keep: action.keep });
  } catch (error) {
    yield put({type: User.USER_LOGIN_FAILURE, error});
  }
}

export function* listFavoritesSaga(action) {
  yield call(listFavorites);
}

export function* toggleFavoriteSaga(action) {
  yield call(toggleFavorite, action.roomID);
}

export function* changePictureSaga(action) {
  const {image} = yield select(state => state.images[action.ref]);
  const user = yield select(state => state.user);
  yield call(changePicture, image);
}

export function* logoutSaga(action) {
  window.logout = true;
  window.socket.disconnect(true);
  localStorage.removeItem('token');
}

export function* registerSaga(action) {
  try {
    yield call(postRegister, action);
    yield put({type: User.USER_LOGIN, email: action.email, password: action.password});
  }
  catch (error) {
    yield put({type: User.USER_REGISTER_FAILURE, error});
  }
}
